# La vigencia de los clásicos en Billboard

## Pregunta del proyecto

¿Qué canciones con debut registrado en el Hot 100 durante los años 80 y 90 reaparecieron entre 2020 y 2025, qué posiciones alcanzaron y cuántas semanas fueron observadas?

Esta es una primera pregunta medible para investigar la idea de que la música antigua conserva popularidad. No demuestra que la música antigua concentre la mayoría de escuchas ni que la música actual sea más efímera. El Hot 100 es una selección de éxitos, no el universo de escucha. Su ranking tampoco es una cantidad de reproducciones.

## Fuente y período

- Dataset: Billboard Hot 100 & more, Godefroy Lambert (ludmin), Kaggle: https://www.kaggle.com/datasets/ludmin/billboard
- Versión descargada: 179. Consulta y descarga: 14 de octubre de 2026, Costa Rica.
- Licencia declarada en la API pública de Kaggle: CC BY-NC-SA 4.0. Se requiere atribución, uso no comercial y compartir las adaptaciones bajo la misma licencia. Texto: https://creativecommons.org/licenses/by-nc-sa/4.0/
- Se usó únicamente `hot100.csv`. `billboard200.csv` contiene álbumes, pese al nombre Song de su columna: no se mezclaron con canciones. No se sumaron posiciones de distintos rankings.
- Historia utilizada para calcular la primera observación: 355.858 filas, desde 1958-07-30 hasta 2026-10-07 según la fuente.
- Ventana analítica elegida: los seis años completos 2020-2025. No se compara un 2026 parcial con años completos.
- Se conservan las fechas de la fuente, que aparecen como miércoles. No se reinterpretan como la fecha oficial de cierre de Billboard ni se desplazan automáticamente. Antes de estudiar un evento con precisión de días, verificar contra el ranking oficial.

## Archivos y uso

| Archivo | Filas | Función |
|---|---:|---|
| lote_01.csv | 15.700 | Observaciones 2020-2022 para primera ingesta |
| lote_02.csv | 15.700 | Observaciones 2023-2025 para segunda ingesta |
| catalogo_canciones.csv | 32.694 | Una fila por identificador de título y crédito de artista de toda la historia |
| candidatas_80_90.csv | 8 | Resultado provisional de canciones con debut observado en los 80/90 y presencia en 2020-2025 |
| presencia_anual_por_decada_debut.csv | 45 | Participación anual de puestos observados por década de debut |
| control_calidad.csv | 14 | Conteos de cobertura, duplicados y datos faltantes por lote |
| diccionario_datos.csv | 55 | Definición, tipo recomendado y significado de todos los campos anteriores |
| fuentes_y_validacion.json | — | Procedencia, versión, huellas digitales y verificaciones |

CSV con coma, cabecera y UTF-8 con BOM para facilitar la apertura en Excel. Las comillas internas se escapan según CSV estándar. Importar inicialmente como texto para conservar guiones y vacíos. No abrir y guardar los archivos originales desde Excel si se quiere preservar exactamente el insumo para Databricks.

Los 31.400 registros son observaciones reales de la fuente, no datos sintéticos. Los identificadores, lotes, catálogo, controles y resúmenes son derivados. No se inyectaron errores ficticios entre las observaciones reales.

## Identidad y fecha original

El grano del hecho es una canción acreditada, en una fecha observada, en Hot 100. La llave de posición es `(chart_id, chart_date_source, rank)`. La llave para deduplicación de negocio es `(chart_id, chart_date_source, song_id)`.

`song_id` es el SHA256 de un JSON compacto UTF-8 con `[título.strip(), crédito.strip()]`. Es una identidad textual conservadora. No es ISRC, identificador de Spotify ni de MusicBrainz. No fusiona automáticamente remasterizaciones, cambios de crédito, colaboraciones o versiones en vivo. Los títulos y créditos originales se mantienen en los lotes.

La fecha mínima histórica y su década se llaman `first_hot100_date_source` y `first_hot100_decade`. Son fechas de debut observado, no fechas de lanzamiento. Una canción de diciembre de 1979 puede debutar en 1980; una de 1999 puede debutar en 2000. El filtro provisional puede excluir o incluir casos en los bordes. No se debe presentar esta selección como lista exhaustiva de todas las canciones originalmente publicadas en esas décadas.

`original_release_year` permanece vacío cuando no se verificó. Dos ejemplos documentados:

- Running Up That Hill, Kate Bush: 1985. El canal oficial identifica el lanzamiento del single el 5 de agosto de 1985: https://www.youtube.com/watch?v=wp43OdtAAkM
- Thriller, Michael Jackson: 1982, publicación en el álbum original. Su debut registrado en Hot 100 es de 1984, ejemplo de por qué ambas fechas difieren: https://www.michaeljackson.com/albums/thriller/

Para completar la pregunta por **década de lanzamiento**, enriquecer el catálogo con el año más temprano documentado de la grabación original y su fuente. MusicBrainz permite distinguir grabación y sus diferentes publicaciones: https://musicbrainz.org/doc/Recording . Validar artista, título, versiones y precisión de fecha; una coincidencia textual por sí sola no valida identidad. Registrar el vínculo a la fuente en `release_year_source_url` y actualizar `release_year_status`. No convertir una fecha parcial en un día inventado.

## Resultados provisionales

Orden: semanas distintas observadas en 2020-2025, seguido por mejor posición. No es una clasificación por streams.

| Canción | Artista | Semanas observadas | Mejor puesto |
|---|---|---:|---:|
| Running Up That Hill (A Deal With God) | Kate Bush | 20 | 3 |
| Thriller | Michael Jackson | 7 | 10 |
| Ghostbusters | Ray Parker Jr. | 5 | 22 |
| Still D.R.E. | Dr. Dre Featuring Snoop Dogg | 3 | 23 |
| Somebody's Watching Me | Rockwell | 3 | 24 |
| Mama, I'm Coming Home | Ozzy Osbourne | 2 | 48 |
| Ruff Ryders' Anthem | DMX | 1 | 16 |
| Fast Car | Tracy Chapman | 1 | 42 |

Solo las dos primeras tienen el año original completado en este paquete. Las otras seis son candidatas por debut histórico. Los conteos describen la versión descargada y no certifican que la fuente refleje sin errores cada ranking oficial.

La tabla anual usa como denominador **todos los puestos observados en ese año**, incluidas las otras décadas. `share_chart_entries` no es porcentaje de canciones únicas, de oyentes ni de reproducciones. Conservar todas las décadas evita seleccionar únicamente clásicos y luego inferir que dominan el consumo.

## Cómo responde a la consigna de Databricks

El diseño corresponde al proyecto final M4 disponible en la conversación. No se tuvo acceso al archivo inicialmente llamado «Estudio de caso # 2-2.pdf».

1. **Bronze incremental:** subir solo `lote_01.csv` a un volume de entrada. Ingerir con Auto Loader, schemaLocation y checkpoint persistentes, conservando `_metadata.file_path`. Después agregar `lote_02.csv` al mismo directorio y volver a ejecutar. Esperado: 15.700 y 15.700 filas por batch_id, 31.400 en total. Reejecutar sin archivos nuevos debe mantener esos conteos. Este comportamiento se debe demostrar en Databricks; los CSV por sí solos no prueban idempotencia. Mantener catálogo y resultados fuera del directorio vigilado de hechos.
2. **Silver:** convertir fecha y posiciones; guiones y vacíos de last_week, peak_position y weeks_in_chart a NULL. No imputar cero, pues no es una posición válida. Rechazar a cuarentena filas con identificador, fecha o posición obligatoria inválidos; deduplicar por llave de negocio. LEFT JOIN al catálogo por song_id y medir cruces sin correspondencia. Con este paquete el cruce esperado conserva 31.400 filas y no deja llaves sin catálogo.
3. **Métricas antes/después:** registrar filas, llaves duplicadas, nulos por campo, cast fallidos, posiciones fuera de rango y cobertura del catálogo. Los guiones reales proporcionan casos para la limpieza. La fuente no presenta duplicados de negocio en estos dos lotes: una deduplicación correcta puede quitar cero filas. Si se necesita una demostración con duplicados, usar una copia de prueba identificada por separado.
4. **Gold y calidad:** construir una vista que reproduzca candidatas_80_90.csv y otra con presencia anual. Para la pregunta definitiva usar original_release_year verificado. Aplicar al menos dos restricciones reales, por ejemplo rank NOT NULL y CHECK(rank BETWEEN 1 AND 100). Insertar una fila de prueba con rank=101 en una tabla de prueba con esas restricciones y conservar el error literal de Databricks. No inventar ese output.
5. **Orquestación:** tareas bronze, silver y gold, dependencias, reintentos y disparador. Hay que configurar y mostrar una corrida en el workspace.
6. **Gobernanza:** esquemas por capa y perfil lector. Estos datos son públicos y no incluyen datos personales sensibles. Puede restringirse el acceso a lotes por una tabla de mapeo de perfiles, si el profesor considera apropiada la demostración. No etiquetar nombres públicos de artistas como datos personales confidenciales para fabricar un requisito. Un reemplazo opcional de C3 debe acordarse y documentarse.
7. **CI/CD y observabilidad:** guardar notebooks y README en GitHub y demostrar PR integrado; usar el hecho como tabla mayor para clustering y OPTIMIZE, consultar las tablas del sistema y capturar evidencias. Son acciones pendientes del proyecto en Databricks, no resultados ya ejecutados.
8. **Opcional O9:** documentar el uso de un agente: investigación de fuente y licencia, preparación de archivos, diseño del catálogo y controles; correcciones necesarias, especialmente separar debut de lanzamiento. La parte de programación con CLI y su evidencia debe realizarse si se elige O9. Esta preparación local no equivale por sí sola al opcional completo.

## Otras fuentes y ampliación de la hipótesis

- **Kworb:** sus tablas de los 80/90 muestran acumulados y columna Daily. Sirven como fotografía complementaria de las canciones listadas. Una captura no reconstruye una serie de varios años. Conservar fecha de captura y verificar cobertura antes de comparar: https://kworb.net/spotify/songs_1980.html y https://kworb.net/spotify/songs_1990.html . No se incorporaron filas de Kworb en este paquete.
- **Spotify Charts de Kaggle:** investigar fechas, regiones y cobertura de los archivos antes de incorporarlos. No sumar Global junto a los países porque puede duplicar población. Distinguir Top 200 de Viral 50. https://www.kaggle.com/datasets/dhruvildave/spotify-charts
- **ListenBrainz:** permite estudiar eventos de escucha de su comunidad, no estimar directamente toda la audiencia de Spotify: https://listenbrainz.org/data/

Para estudiar si la música reciente es más efímera, comparar cohortes con igual seguimiento desde el debut, evitar comparar éxitos antiguos sobrevivientes con todos los lanzamientos nuevos, y analizar cambios de reglas de elegibilidad del chart. Para estudiar si «se escucha más música vieja», hacen falta reproducciones por período y una cobertura apropiada de catálogo antiguo y reciente. No se pueden sumar rankings o acumulados de plataformas diferentes como si fueran la misma medida.

## Reproducibilidad y validación

Las huellas y conteos están en fuentes_y_validacion.json. Fuente original: descargar la versión 179 del dataset desde Kaggle. El SHA256 de hot100.csv dentro del ZIP permite confirmar el insumo. El paquete contiene los archivos derivados, no todos los datos de las otras listas de Kaggle.

Se verificaron posiciones entre 1 y 100, unicidad de llaves de negocio y posición, integridad del cruce muchos-a-uno, ausencia de expansión de filas y conteos al reabrir los CSV. control_calidad.csv registra también fechas con distinto número de filas y huecos semanales entre los extremos observados. No se ejecutaron notebooks ni jobs en Databricks.
